// export const HOMEPAGE_BASE = "https://wp.mortuus.no";
export const HOMEPAGE_PATH = "/vttes-util";
