export const BASE_URL = 'http://www.wp.mortuus.no/wp-json/';
export const TOKEN_PATH = "jwt-auth/v1/token";
export const CHARACTER_PATH = "wp/v2/character";